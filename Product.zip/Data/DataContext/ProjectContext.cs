﻿
using Domain.Entities;
using System;
using Microsoft.EntityFrameworkCore;
//using Domain.Entities.Categorys;

namespace Infrastructure.DataContext;

public class ProjectContext:DbContext
{
    public ProjectContext(DbContextOptions<ProjectContext> options)
            : base(options)
    {
    }

    public DbSet<Product> Products { get; set; }
    public DbSet<Category> Categories { get; set; }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        

    }
}

